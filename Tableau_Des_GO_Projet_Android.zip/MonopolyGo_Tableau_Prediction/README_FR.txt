TABLEAU DÉS GO — PROJET ANDROID

IMPORTANT
Ce projet est un tableau statistique indépendant. Il ne se connecte pas à Monopoly GO,
ne lit pas l'écran du jeu et ne peut pas prédire les prochains résultats. Les exemples
de combinaisons affichés par multiplicateur sont illustratifs. Les probabilités sont
les probabilités mathématiques de la somme de deux dés équilibrés.

CRÉER L'APK
1. Installe Android Studio sur un ordinateur.
2. Ouvre Android Studio > Open, puis sélectionne le dossier TableauDesGO décompressé.
3. Laisse Android Studio synchroniser Gradle et installer les composants Android demandés.
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Récupère l'APK dans app/build/outputs/apk/debug/app-debug.apk.
6. Transfère-le sur ton téléphone Android et autorise l'installation depuis cette source.

UTILISATION
Saisis manuellement les deux valeurs observées dans le jeu puis appuie sur Ajouter.
L'application calcule les fréquences de ton historique local. Elle ne lance aucun dé,
n'interagit pas avec le jeu et ne contourne aucune protection.
